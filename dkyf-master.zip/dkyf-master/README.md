# dont kill your friends
> a text-based battle-royale

### and dont kill them for free

[![Deploy to Heroku](https://www.herokucdn.com/deploy/button.png)](https://heroku.com/deploy)

### Overview

- [x] Connect to pals using web sockets.

- [x] Ready up and start a game. 

- [ ] Actually play a game.


### Local Development

1. __`npm install`__

1. __`npm run dev`__
